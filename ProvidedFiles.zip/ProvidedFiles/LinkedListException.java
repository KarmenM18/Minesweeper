
public class LinkedListException extends RuntimeException {

	public LinkedListException(String exc) {
		super("Error: " + exc);
	}
	
}